from gensim.models import word2vec
model = word2vec.Word2Vec.load('text/夏目漱石.model')

